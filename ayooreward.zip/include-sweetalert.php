<script src="sweetalert/dist/sweetalert-dev.js"></script>
<link rel="stylesheet" href="sweetalert/dist/sweetalert.css">